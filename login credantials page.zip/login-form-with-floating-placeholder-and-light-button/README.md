# Login Form with floating placeholder and light button

A Pen created on CodePen.io. Original URL: [https://codepen.io/harshitgupta-io/pen/PoePJJv](https://codepen.io/harshitgupta-io/pen/PoePJJv).

